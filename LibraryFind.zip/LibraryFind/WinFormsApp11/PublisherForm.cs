using System;
using System.Windows.Forms;
using WinFormsApp11.Models;

namespace WinFormsApp11
{
    public partial class PublisherForm : Form
    {
        public string PublisherName { get; private set; }
        private TextBox txtName;

        public PublisherForm(Publisher publisher = null)
        {
            InitializeComponent();
            if (publisher != null)
            {
                this.Text = "Изменить издательство";
                txtName.Text = publisher.Name;
            }
        }

        private void InitializeComponent()
        {
            this.Text = "Добавить издательство";
            this.ClientSize = new System.Drawing.Size(300, 120);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;

            var lblName = new Label { Text = "Название:", Location = new System.Drawing.Point(10, 10), Size = new System.Drawing.Size(80, 20) };
            txtName = new TextBox { Location = new System.Drawing.Point(100, 10), Size = new System.Drawing.Size(180, 20) };
            
            var btnOk = new Button { Text = "ОК", DialogResult = DialogResult.OK, Location = new System.Drawing.Point(120, 60), Size = new System.Drawing.Size(75, 25) };
            btnOk.Click += (sender, e) => {
                this.PublisherName = txtName.Text;
            };

            var btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Location = new System.Drawing.Point(205, 60), Size = new System.Drawing.Size(75, 25) };

            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
        }
    }
} 