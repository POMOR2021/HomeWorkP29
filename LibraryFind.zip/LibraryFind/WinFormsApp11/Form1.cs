using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using WinFormsApp11.Models;

namespace WinFormsApp11
{
    public partial class Form1 : Form
    {
        private TextBox tbFind;
        private Button btFind;
        private DataGridView dataGridView;
        private LibraryDbEngContext dbContext;

        public Form1()
        {
            InitializeComponent();
            InitializeDatabase();
            InitializeCustomComponents();
        }

        private void InitializeDatabase()
        {
            dbContext = new LibraryDbEngContext();
            dbContext.Database.EnsureCreated();
            SeedDatabase();
        }

        private void SeedDatabase()
        {
            if (dbContext.Books.Any()) return;

            var authors = new[]
            {
                new Author { FirstName = "Александр", LastName = "Пушкин" },
                new Author { FirstName = "Фёдор", LastName = "Достоевский" },
                new Author { FirstName = "Лев", LastName = "Толстой" },
                new Author { FirstName = "Сергей", LastName = "Есенин" },
                new Author { FirstName = "Михаил", LastName = "Булгаков" }
            };
            dbContext.Authors.AddRange(authors);

            var publishers = new[]
            {
                new Publisher { Name = "Эксмо" },
                new Publisher { Name = "АСТ" },
                new Publisher { Name = "Азбука" },
                new Publisher { Name = "Росмэн" },
                new Publisher { Name = "Альпина" }
            };
            dbContext.Publishers.AddRange(publishers);
            dbContext.SaveChanges();

            var authorsList = dbContext.Authors.ToList();
            var publishersList = dbContext.Publishers.ToList();

            var books = new[]
            {
                new Book { Title = "Евгений Онегин", AuthorId = authorsList[0].AuthorId, PublisherId = publishersList[0].PublisherId },
                new Book { Title = "Капитанская дочка", AuthorId = authorsList[0].AuthorId, PublisherId = publishersList[1].PublisherId },
                new Book { Title = "Преступление и наказание", AuthorId = authorsList[1].AuthorId, PublisherId = publishersList[0].PublisherId },
                new Book { Title = "Братья Карамазовы", AuthorId = authorsList[1].AuthorId, PublisherId = publishersList[2].PublisherId },
                new Book { Title = "Война и мир", AuthorId = authorsList[2].AuthorId, PublisherId = publishersList[1].PublisherId },
                new Book { Title = "Анна Каренина", AuthorId = authorsList[2].AuthorId, PublisherId = publishersList[1].PublisherId },
                new Book { Title = "Черный человек", AuthorId = authorsList[3].AuthorId, PublisherId = publishersList[3].PublisherId },
                new Book { Title = "Москва кабацкая", AuthorId = authorsList[3].AuthorId, PublisherId = publishersList[3].PublisherId },
                new Book { Title = "Мастер и Маргарита", AuthorId = authorsList[4].AuthorId, PublisherId = publishersList[4].PublisherId },
                new Book { Title = "Собачье сердце", AuthorId = authorsList[4].AuthorId, PublisherId = publishersList[4].PublisherId }
            };
            dbContext.Books.AddRange(books);
            dbContext.SaveChanges();
        }

        private void InitializeCustomComponents()
        {
            this.Controls.Clear();
            this.Text = "Поиск книг по фамилии автора";
            this.ClientSize = new System.Drawing.Size(700, 400);

            tbFind = new TextBox
            {
                Name = "tbFind",
                Location = new System.Drawing.Point(12, 12),
                Size = new System.Drawing.Size(250, 23)
            };
            tbFind.TextChanged += TbFind_TextChanged;
            this.Controls.Add(tbFind);

            btFind = new Button
            {
                Name = "btFind",
                Text = "Найти",
                Location = new System.Drawing.Point(270, 11),
                Size = new System.Drawing.Size(75, 25),
                Enabled = false
            };
            btFind.Click += BtFind_Click;
            this.Controls.Add(btFind);

            dataGridView = new DataGridView
            {
                Location = new System.Drawing.Point(12, 45),
                Size = new System.Drawing.Size(670, 340),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false
            };
            this.Controls.Add(dataGridView);
        }

        private void TbFind_TextChanged(object sender, EventArgs e)
        {
            btFind.Enabled = !string.IsNullOrWhiteSpace(tbFind.Text);
        }

        private void BtFind_Click(object sender, EventArgs e)
        {
            string searchText = tbFind.Text.Trim();
            var query =
                from book in dbContext.Books
                join author in dbContext.Authors on book.AuthorId equals author.AuthorId
                join publisher in dbContext.Publishers on book.PublisherId equals publisher.PublisherId
                where author.LastName.Contains(searchText)
                select new
                {
                    Название = book.Title,
                    Имя_Автора = author.FirstName,
                    Фамилия_Автора = author.LastName,
                    Издательство = publisher.Name
                };
            dataGridView.DataSource = query.ToList();
        }

        private void Form1_Load(object sender, EventArgs e) { }
    }
}
