USE master;
GO

IF EXISTS (SELECT * FROM sys.databases WHERE name = 'LibraryDB_Eng')
BEGIN
    ALTER DATABASE LibraryDB_Eng SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE LibraryDB_Eng;
END
GO

CREATE DATABASE LibraryDB_Eng COLLATE SQL_Latin1_General_CP1_CI_AS;
GO

USE LibraryDB_Eng;
GO

CREATE TABLE Authors (
    AuthorId INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL
);
GO

CREATE TABLE Publishers (
    PublisherId INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE Books (
    BookId INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    AuthorId INT NOT NULL,
    PublisherId INT NOT NULL,
    FOREIGN KEY (AuthorId) REFERENCES Authors(AuthorId),
    FOREIGN KEY (PublisherId) REFERENCES Publishers(PublisherId)
);
GO

INSERT INTO Authors (FirstName, LastName) VALUES
(N'Alexander', N'Pushkin'),
(N'Fyodor', N'Dostoevsky'),
(N'Leo', N'Tolstoy'),
(N'Sergei', N'Yesenin'),
(N'Mikhail', N'Bulgakov');
GO

INSERT INTO Publishers (Name) VALUES
(N'Penguin Classics'),
(N'Oxford Press'),
(N'HarperCollins'),
(N'Random House'),
(N'Simon & Schuster');
GO

INSERT INTO Books (Title, AuthorId, PublisherId) VALUES
(N'Eugene Onegin', 1, 1),
(N'The Captain''s Daughter', 1, 2),
(N'Crime and Punishment', 2, 1),
(N'The Brothers Karamazov', 2, 3),
(N'War and Peace', 3, 2),
(N'Anna Karenina', 3, 2),
(N'Black Man', 4, 4),
(N'Moscow Tavern', 4, 4),
(N'The Master and Margarita', 5, 5),
(N'Heart of a Dog', 5, 5);
GO 