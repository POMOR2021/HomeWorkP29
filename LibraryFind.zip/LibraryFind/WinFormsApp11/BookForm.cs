using System;
using System.Linq;
using System.Windows.Forms;
using WinFormsApp11.Models;

namespace WinFormsApp11
{
    public partial class BookForm : Form
    {
        public string BookTitle { get; private set; }
        public int AuthorId { get; private set; }
        public int PublisherId { get; private set; }

        private TextBox txtTitle;
        private ComboBox cmbAuthors;
        private ComboBox cmbPublishers;

        public BookForm(LibraryDBContext dbContext, Book book = null)
        {
            InitializeComponent();
            LoadComboBoxes(dbContext);

            if (book != null)
            {
                this.Text = "Изменить книгу";
                txtTitle.Text = book.Title;
                cmbAuthors.SelectedValue = book.AuthorId;
                cmbPublishers.SelectedValue = book.PublisherId;
            }
        }

        private void InitializeComponent()
        {
            this.Text = "Добавить книгу";
            this.ClientSize = new System.Drawing.Size(350, 200);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;

            var lblTitle = new Label { Text = "Название:", Location = new System.Drawing.Point(10, 10), Size = new System.Drawing.Size(80, 20) };
            txtTitle = new TextBox { Location = new System.Drawing.Point(120, 10), Size = new System.Drawing.Size(210, 20) };

            var lblAuthor = new Label { Text = "Автор:", Location = new System.Drawing.Point(10, 40), Size = new System.Drawing.Size(80, 20) };
            cmbAuthors = new ComboBox { Location = new System.Drawing.Point(120, 40), Size = new System.Drawing.Size(210, 20), DropDownStyle = ComboBoxStyle.DropDownList };

            var lblPublisher = new Label { Text = "Издательство:", Location = new System.Drawing.Point(10, 70), Size = new System.Drawing.Size(100, 20) };
            cmbPublishers = new ComboBox { Location = new System.Drawing.Point(120, 70), Size = new System.Drawing.Size(210, 20), DropDownStyle = ComboBoxStyle.DropDownList };

            var btnOk = new Button { Text = "ОК", DialogResult = DialogResult.OK, Location = new System.Drawing.Point(170, 140), Size = new System.Drawing.Size(75, 25) };
            btnOk.Click += (sender, e) => {
                this.BookTitle = txtTitle.Text;
                this.AuthorId = (int)cmbAuthors.SelectedValue;
                this.PublisherId = (int)cmbPublishers.SelectedValue;
            };

            var btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Location = new System.Drawing.Point(255, 140), Size = new System.Drawing.Size(75, 25) };

            this.Controls.Add(lblTitle);
            this.Controls.Add(txtTitle);
            this.Controls.Add(lblAuthor);
            this.Controls.Add(cmbAuthors);
            this.Controls.Add(lblPublisher);
            this.Controls.Add(cmbPublishers);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
        }

        private void LoadComboBoxes(LibraryDBContext dbContext)
        {
            cmbAuthors.DataSource = dbContext.Authors.ToList();
            cmbAuthors.DisplayMember = "LastName";
            cmbAuthors.ValueMember = "AuthorId";

            cmbPublishers.DataSource = dbContext.Publishers.ToList();
            cmbPublishers.DisplayMember = "Name";
            cmbPublishers.ValueMember = "PublisherId";
        }
    }
} 