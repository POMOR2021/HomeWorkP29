using System;
using System.Windows.Forms;
using WinFormsApp11.Models;

namespace WinFormsApp11
{
    public partial class AuthorForm : Form
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }

        private TextBox txtFirstName;
        private TextBox txtLastName;

        public AuthorForm(Author author = null)
        {
            InitializeComponent();
            if (author != null)
            {
                this.Text = "Изменить автора";
                txtFirstName.Text = author.FirstName;
                txtLastName.Text = author.LastName;
            }
        }

        private void InitializeComponent()
        {
            this.Text = "Добавить автора";
            this.ClientSize = new System.Drawing.Size(300, 150);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;

            var lblFirstName = new Label { Text = "Имя:", Location = new System.Drawing.Point(10, 10), Size = new System.Drawing.Size(80, 20) };
            txtFirstName = new TextBox { Location = new System.Drawing.Point(100, 10), Size = new System.Drawing.Size(180, 20) };

            var lblLastName = new Label { Text = "Фамилия:", Location = new System.Drawing.Point(10, 40), Size = new System.Drawing.Size(80, 20) };
            txtLastName = new TextBox { Location = new System.Drawing.Point(100, 40), Size = new System.Drawing.Size(180, 20) };

            var btnOk = new Button { Text = "ОК", DialogResult = DialogResult.OK, Location = new System.Drawing.Point(120, 90), Size = new System.Drawing.Size(75, 25) };
            btnOk.Click += (sender, e) => {
                this.FirstName = txtFirstName.Text;
                this.LastName = txtLastName.Text;
            };

            var btnCancel = new Button { Text = "Отмена", DialogResult = DialogResult.Cancel, Location = new System.Drawing.Point(205, 90), Size = new System.Drawing.Size(75, 25) };

            this.Controls.Add(lblFirstName);
            this.Controls.Add(txtFirstName);
            this.Controls.Add(lblLastName);
            this.Controls.Add(txtLastName);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
        }
    }
} 