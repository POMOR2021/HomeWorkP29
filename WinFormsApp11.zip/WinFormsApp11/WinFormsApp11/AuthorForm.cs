using System;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class AuthorForm : Form
    {
        public TextBox TxtAuthorFirstName { get; private set; }
        public TextBox TxtAuthorLastName { get; private set; }

        public AuthorForm(string firstName = "", string lastName = "")
        {
            InitializeComponent();
            TxtAuthorFirstName.Text = firstName;
            TxtAuthorLastName.Text = lastName;
        }

        private void InitializeComponent()
        {
            this.TxtAuthorFirstName = new System.Windows.Forms.TextBox();
            this.TxtAuthorLastName = new System.Windows.Forms.TextBox();
            var lblFirstName = new System.Windows.Forms.Label();
            var lblLastName = new System.Windows.Forms.Label();
            var btnOk = new System.Windows.Forms.Button();
            var btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            this.TxtAuthorFirstName.Location = new System.Drawing.Point(100, 25);
            this.TxtAuthorFirstName.Name = "TxtAuthorFirstName";
            this.TxtAuthorFirstName.Size = new System.Drawing.Size(150, 20);
            
            this.TxtAuthorLastName.Location = new System.Drawing.Point(100, 65);
            this.TxtAuthorLastName.Name = "TxtAuthorLastName";
            this.TxtAuthorLastName.Size = new System.Drawing.Size(150, 20);
            
            lblFirstName.Location = new System.Drawing.Point(20, 25);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new System.Drawing.Size(70, 20);
            lblFirstName.Text = "Имя:";

            lblLastName.Location = new System.Drawing.Point(20, 65);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new System.Drawing.Size(70, 20);
            lblLastName.Text = "Фамилия:";
            
            btnOk.Location = new System.Drawing.Point(60, 120);
            btnOk.Name = "btnOk";
            btnOk.Size = new System.Drawing.Size(75, 23);
            btnOk.Text = "ОК";
            btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            btnOk.Click += (sender, e) => { this.AcceptButton = btnOk; };
            
            btnCancel.Location = new System.Drawing.Point(150, 120);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(75, 23);
            btnCancel.Text = "Отмена";
            btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.TxtAuthorFirstName);
            this.Controls.Add(this.TxtAuthorLastName);
            this.Controls.Add(lblFirstName);
            this.Controls.Add(lblLastName);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
            this.Name = "AuthorForm";
            this.Text = "Автор";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
} 