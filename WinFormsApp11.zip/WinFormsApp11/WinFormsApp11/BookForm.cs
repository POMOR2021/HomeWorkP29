using System;
using System.Collections.Generic;
using System.Windows.Forms;
// Assuming you will have these models from EF
// using WinFormsApp11.Models; 

namespace WinFormsApp11
{
    public partial class BookForm : Form
    {
        public TextBox TxtBookTitle { get; private set; }
        public ComboBox CmbAuthors { get; private set; }
        public ComboBox CmbPublishers { get; private set; }

        public BookForm(string title = "") // We will pass lists of authors and publishers later
        {
            InitializeComponent();
            TxtBookTitle.Text = title;
            // Populate ComboBoxes here later
        }

        private void InitializeComponent()
        {
            this.TxtBookTitle = new System.Windows.Forms.TextBox();
            this.CmbAuthors = new System.Windows.Forms.ComboBox();
            this.CmbPublishers = new System.Windows.Forms.ComboBox();
            var lblTitle = new System.Windows.Forms.Label();
            var lblAuthor = new System.Windows.Forms.Label();
            var lblPublisher = new System.Windows.Forms.Label();
            var btnOk = new System.Windows.Forms.Button();
            var btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // TxtBookTitle
            this.TxtBookTitle.Location = new System.Drawing.Point(100, 25);
            this.TxtBookTitle.Name = "TxtBookTitle";
            this.TxtBookTitle.Size = new System.Drawing.Size(150, 20);

            // CmbAuthors
            this.CmbAuthors.FormattingEnabled = true;
            this.CmbAuthors.Location = new System.Drawing.Point(100, 65);
            this.CmbAuthors.Name = "CmbAuthors";
            this.CmbAuthors.Size = new System.Drawing.Size(150, 21);

            // CmbPublishers
            this.CmbPublishers.FormattingEnabled = true;
            this.CmbPublishers.Location = new System.Drawing.Point(100, 105);
            this.CmbPublishers.Name = "CmbPublishers";
            this.CmbPublishers.Size = new System.Drawing.Size(150, 21);

            // lblTitle
            lblTitle.Location = new System.Drawing.Point(20, 25);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new System.Drawing.Size(70, 20);
            lblTitle.Text = "Название:";

            // lblAuthor
            lblAuthor.Location = new System.Drawing.Point(20, 65);
            lblAuthor.Name = "lblAuthor";
            lblAuthor.Size = new System.Drawing.Size(70, 20);
            lblAuthor.Text = "Автор:";

            // lblPublisher
            lblPublisher.Location = new System.Drawing.Point(20, 105);
            lblPublisher.Name = "lblPublisher";
            lblPublisher.Size = new System.Drawing.Size(70, 20);
            lblPublisher.Text = "Издательство:";
            
            // btnOk
            btnOk.Location = new System.Drawing.Point(60, 160);
            btnOk.Name = "btnOk";
            btnOk.Size = new System.Drawing.Size(75, 23);
            btnOk.Text = "ОК";
            btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            btnOk.Click += (sender, e) => { this.AcceptButton = btnOk; };

            // btnCancel
            btnCancel.Location = new System.Drawing.Point(150, 160);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(75, 23);
            btnCancel.Text = "Отмена";
            btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            // BookForm
            this.ClientSize = new System.Drawing.Size(284, 211);
            this.Controls.Add(this.TxtBookTitle);
            this.Controls.Add(this.CmbAuthors);
            this.Controls.Add(this.CmbPublishers);
            this.Controls.Add(lblTitle);
            this.Controls.Add(lblAuthor);
            this.Controls.Add(lblPublisher);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
            this.Name = "BookForm";
            this.Text = "Книга";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
} 