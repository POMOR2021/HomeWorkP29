using System;
using System.Windows.Forms;

namespace WinFormsApp11
{
    public partial class PublisherForm : Form
    {
        public TextBox TxtPublisherName { get; private set; }

        public PublisherForm(string name = "")
        {
            InitializeComponent();
            TxtPublisherName.Text = name;
        }

        private void InitializeComponent()
        {
            this.TxtPublisherName = new System.Windows.Forms.TextBox();
            var lblName = new System.Windows.Forms.Label();
            var btnOk = new System.Windows.Forms.Button();
            var btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            
            this.TxtPublisherName.Location = new System.Drawing.Point(100, 25);
            this.TxtPublisherName.Name = "TxtPublisherName";
            this.TxtPublisherName.Size = new System.Drawing.Size(150, 20);
            
            lblName.Location = new System.Drawing.Point(20, 25);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(70, 20);
            lblName.Text = "Название:";
            
            btnOk.Location = new System.Drawing.Point(60, 80);
            btnOk.Name = "btnOk";
            btnOk.Size = new System.Drawing.Size(75, 23);
            btnOk.Text = "ОК";
            btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            btnOk.Click += (sender, e) => { this.AcceptButton = btnOk; };

            btnCancel.Location = new System.Drawing.Point(150, 80);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(75, 23);
            btnCancel.Text = "Отмена";
            btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;

            this.ClientSize = new System.Drawing.Size(284, 121);
            this.Controls.Add(this.TxtPublisherName);
            this.Controls.Add(lblName);
            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);
            this.Name = "PublisherForm";
            this.Text = "Издательство";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
} 