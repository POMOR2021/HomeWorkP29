using System;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using WinFormsApp11.Models;

namespace WinFormsApp11
{
    public partial class Form1 : Form
    {
        private TabControl tabControl;
        private DataGridView booksGridView;
        private DataGridView authorsGridView;
        private DataGridView publishersGridView;
        private LibraryDBContext dbContext;

        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
            InitializeDatabase();
            ConfigureGridViews();
            LoadData();
            BindEvents();
        }

        private void ConfigureGridViews()
        {
            ConfigureAuthorsGridView();
            ConfigureBooksGridView();
            ConfigurePublishersGridView();
        }

        private void ConfigureAuthorsGridView()
        {
            authorsGridView.AutoGenerateColumns = false;
            authorsGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "FirstName",
                HeaderText = "Имя",
                Width = 150
            });
            authorsGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "LastName",
                HeaderText = "Фамилия",
                Width = 150
            });
        }

        private void ConfigureBooksGridView()
        {
            booksGridView.AutoGenerateColumns = false;
            booksGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Title",
                HeaderText = "Название",
                Width = 200
            });
            booksGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Author",
                HeaderText = "Автор",
                Width = 150
            });
            booksGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Publisher",
                HeaderText = "Издательство",
                Width = 150
            });
            booksGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "BookId",
                HeaderText = "ID",
                Width = 50,
                Visible = false
            });
        }

        private void ConfigurePublishersGridView()
        {
            publishersGridView.AutoGenerateColumns = false;
            publishersGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Name",
                HeaderText = "Название",
                Width = 200
            });
        }

        private void InitializeDatabase()
        {
            dbContext = new LibraryDBContext();
            SeedDatabase();
        }

        private void SeedDatabase()
        {
            if (dbContext.Authors.Any())
            {
                return; // DB has been seeded
            }

            var authors = new[]
            {
                new Author { FirstName = "Александр", LastName = "Пушкин" },
                new Author { FirstName = "Фёдор", LastName = "Достоевский" },
                new Author { FirstName = "Лев", LastName = "Толстой" },
                new Author { FirstName = "Сергей", LastName = "Есенин" },
                new Author { FirstName = "Михаил", LastName = "Булгаков" }
            };
            dbContext.Authors.AddRange(authors);

            var publishers = new[]
            {
                new Publisher { Name = "Эксмо" },
                new Publisher { Name = "АСТ" },
                new Publisher { Name = "Азбука" },
                new Publisher { Name = "Росмэн" },
                new Publisher { Name = "Альпина" }
            };
            dbContext.Publishers.AddRange(publishers);
            dbContext.SaveChanges();

            var books = new[]
            {
                new Book { Title = "Евгений Онегин", AuthorId = 1, PublisherId = 1 },
                new Book { Title = "Капитанская дочка", AuthorId = 1, PublisherId = 2 },
                new Book { Title = "Преступление и наказание", AuthorId = 2, PublisherId = 1 },
                new Book { Title = "Братья Карамазовы", AuthorId = 2, PublisherId = 3 },
                new Book { Title = "Война и мир", AuthorId = 3, PublisherId = 2 },
                new Book { Title = "Анна Каренина", AuthorId = 3, PublisherId = 2 },
                new Book { Title = "Черный человек", AuthorId = 4, PublisherId = 4 },
                new Book { Title = "Москва кабацкая", AuthorId = 4, PublisherId = 4 },
                new Book { Title = "Мастер и Маргарита", AuthorId = 5, PublisherId = 5 },
                new Book { Title = "Собачье сердце", AuthorId = 5, PublisherId = 5 }
            };
            dbContext.Books.AddRange(books);
            dbContext.SaveChanges();
        }

        private void LoadData()
        {
            LoadAuthors();
            LoadBooks();
            LoadPublishers();
        }

        private void LoadAuthors()
        {
            var authors = dbContext.Authors.ToList();
            authorsGridView.DataSource = authors;
        }

        private void LoadBooks()
        {
            var books = dbContext.Books
                .Include(b => b.Author)
                .Include(b => b.Publisher)
                .Select(b => new
                {
                    b.BookId,
                    b.Title,
                    Author = b.Author.FirstName + " " + b.Author.LastName,
                    Publisher = b.Publisher.Name
                })
                .ToList();
            booksGridView.DataSource = books;
        }

        private void LoadPublishers()
        {
            var publishers = dbContext.Publishers.ToList();
            publishersGridView.DataSource = publishers;
        }

        private void BindEvents()
        {
            var authorsTab = tabControl.TabPages[0];
            var authorAddButton = authorsTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Добавить");
            var authorEditButton = authorsTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Изменить");
            var authorDeleteButton = authorsTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Удалить");

            authorAddButton.Click += AuthorAdd_Click;
            authorEditButton.Click += AuthorEdit_Click;
            authorDeleteButton.Click += AuthorDelete_Click;

            var booksTab = tabControl.TabPages[1];
            var bookAddButton = booksTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Добавить");
            var bookEditButton = booksTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Изменить");
            var bookDeleteButton = booksTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Удалить");

            bookAddButton.Click += BookAdd_Click;
            bookEditButton.Click += BookEdit_Click;
            bookDeleteButton.Click += BookDelete_Click;

            var publishersTab = tabControl.TabPages[2];
            var publisherAddButton = publishersTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Добавить");
            var publisherEditButton = publishersTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Изменить");
            var publisherDeleteButton = publishersTab.Controls.OfType<Panel>().First().Controls.OfType<Button>().First(b => b.Text == "Удалить");

            publisherAddButton.Click += PublisherAdd_Click;
            publisherEditButton.Click += PublisherEdit_Click;
            publisherDeleteButton.Click += PublisherDelete_Click;
        }

        private void AuthorAdd_Click(object sender, EventArgs e)
        {
            var form = new AuthorForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                var author = new Author
                {
                    FirstName = form.TxtAuthorFirstName.Text,
                    LastName = form.TxtAuthorLastName.Text
                };
                dbContext.Authors.Add(author);
                dbContext.SaveChanges();
                LoadAuthors();
                LoadBooks();
            }
        }

        private void AuthorEdit_Click(object sender, EventArgs e)
        {
            if (authorsGridView.CurrentRow?.DataBoundItem is Author author)
            {
                var form = new AuthorForm(author.FirstName, author.LastName);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    author.FirstName = form.TxtAuthorFirstName.Text;
                    author.LastName = form.TxtAuthorLastName.Text;
                    dbContext.SaveChanges();
                    LoadAuthors();
                    LoadBooks();
                }
            }
        }

        private void AuthorDelete_Click(object sender, EventArgs e)
        {
            if (authorsGridView.CurrentRow?.DataBoundItem is Author author)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этого автора?", "Подтверждение удаления",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dbContext.Authors.Remove(author);
                    dbContext.SaveChanges();
                    LoadAuthors();
                    LoadBooks();
                }
            }
        }

        private void BookAdd_Click(object sender, EventArgs e)
        {
            var form = new BookForm();
            form.CmbAuthors.DataSource = dbContext.Authors.ToList();
            form.CmbAuthors.DisplayMember = "LastName";
            form.CmbAuthors.ValueMember = "AuthorId";
            form.CmbPublishers.DataSource = dbContext.Publishers.ToList();
            form.CmbPublishers.DisplayMember = "Name";
            form.CmbPublishers.ValueMember = "PublisherId";

            if (form.ShowDialog() == DialogResult.OK)
            {
                var book = new Book
                {
                    Title = form.TxtBookTitle.Text,
                    AuthorId = (int)form.CmbAuthors.SelectedValue,
                    PublisherId = (int)form.CmbPublishers.SelectedValue
                };
                dbContext.Books.Add(book);
                dbContext.SaveChanges();
                LoadBooks();
            }
        }

        private void BookEdit_Click(object sender, EventArgs e)
        {
            if (booksGridView.CurrentRow?.DataBoundItem != null)
            {
                var bookId = (int)booksGridView.CurrentRow.Cells["BookId"].Value;
                var book = dbContext.Books.Find(bookId);
                if (book != null)
                {
                    var form = new BookForm(book.Title);
                    form.CmbAuthors.DataSource = dbContext.Authors.ToList();
                    form.CmbAuthors.DisplayMember = "LastName";
                    form.CmbAuthors.ValueMember = "AuthorId";
                    form.CmbPublishers.DataSource = dbContext.Publishers.ToList();
                    form.CmbPublishers.DisplayMember = "Name";
                    form.CmbPublishers.ValueMember = "PublisherId";

                    form.CmbAuthors.SelectedValue = book.AuthorId;
                    form.CmbPublishers.SelectedValue = book.PublisherId;

                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        book.Title = form.TxtBookTitle.Text;
                        book.AuthorId = (int)form.CmbAuthors.SelectedValue;
                        book.PublisherId = (int)form.CmbPublishers.SelectedValue;
                        dbContext.SaveChanges();
                        LoadBooks();
                    }
                }
            }
        }

        private void BookDelete_Click(object sender, EventArgs e)
        {
            if (booksGridView.CurrentRow?.DataBoundItem != null)
            {
                var bookId = (int)booksGridView.CurrentRow.Cells["BookId"].Value;
                var book = dbContext.Books.Find(bookId);
                if (book != null)
                {
                    if (MessageBox.Show("Вы уверены, что хотите удалить эту книгу?", "Подтверждение удаления",
                        MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        dbContext.Books.Remove(book);
                        dbContext.SaveChanges();
                        LoadBooks();
                    }
                }
            }
        }

        private void PublisherAdd_Click(object sender, EventArgs e)
        {
            var form = new PublisherForm();
            if (form.ShowDialog() == DialogResult.OK)
            {
                var publisher = new Publisher
                {
                    Name = form.TxtPublisherName.Text
                };
                dbContext.Publishers.Add(publisher);
                dbContext.SaveChanges();
                LoadPublishers();
                LoadBooks();
            }
        }

        private void PublisherEdit_Click(object sender, EventArgs e)
        {
            if (publishersGridView.CurrentRow?.DataBoundItem is Publisher publisher)
            {
                var form = new PublisherForm(publisher.Name);
                if (form.ShowDialog() == DialogResult.OK)
                {
                    publisher.Name = form.TxtPublisherName.Text;
                    dbContext.SaveChanges();
                    LoadPublishers();
                    LoadBooks();
                }
            }
        }

        private void PublisherDelete_Click(object sender, EventArgs e)
        {
            if (publishersGridView.CurrentRow?.DataBoundItem is Publisher publisher)
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить это издательство?", "Подтверждение удаления",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    dbContext.Publishers.Remove(publisher);
                    dbContext.SaveChanges();
                    LoadPublishers();
                    LoadBooks();
                }
            }
        }

        private void InitializeCustomComponents()
        {
            tabControl = new TabControl();
            tabControl.Dock = DockStyle.Fill;
            this.Controls.Add(tabControl);

            TabPage authorsTab = new TabPage("Авторы");
            InitializeAuthorsTab(authorsTab);
            tabControl.TabPages.Add(authorsTab);

            TabPage booksTab = new TabPage("Книги");
            InitializeBooksTab(booksTab);
            tabControl.TabPages.Add(booksTab);

            TabPage publishersTab = new TabPage("Издательства");
            InitializePublishersTab(publishersTab);
            tabControl.TabPages.Add(publishersTab);
        }

        private void InitializeAuthorsTab(TabPage authorsTab)
        {
            authorsGridView = new DataGridView();
            authorsGridView.Dock = DockStyle.Fill;
            authorsTab.Controls.Add(authorsGridView);

            Button addButton = new Button { Text = "Добавить", Dock = DockStyle.Bottom };
            Button editButton = new Button { Text = "Изменить", Dock = DockStyle.Bottom };
            Button deleteButton = new Button { Text = "Удалить", Dock = DockStyle.Bottom };
            
            Panel buttonPanel = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            deleteButton.Location = new Point(250, 5);
            editButton.Location = new Point(150, 5);
            addButton.Location = new Point(50, 5);

            buttonPanel.Controls.Add(addButton);
            buttonPanel.Controls.Add(editButton);
            buttonPanel.Controls.Add(deleteButton);
            authorsTab.Controls.Add(buttonPanel);
        }

        private void InitializeBooksTab(TabPage booksTab)
        {
            booksGridView = new DataGridView();
            booksGridView.Dock = DockStyle.Fill;
            booksTab.Controls.Add(booksGridView);

            Button addButton = new Button { Text = "Добавить", Dock = DockStyle.Bottom };
            Button editButton = new Button { Text = "Изменить", Dock = DockStyle.Bottom };
            Button deleteButton = new Button { Text = "Удалить", Dock = DockStyle.Bottom };
            
            Panel buttonPanel = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            deleteButton.Location = new Point(250, 5);
            editButton.Location = new Point(150, 5);
            addButton.Location = new Point(50, 5);

            buttonPanel.Controls.Add(addButton);
            buttonPanel.Controls.Add(editButton);
            buttonPanel.Controls.Add(deleteButton);
            booksTab.Controls.Add(buttonPanel);
        }

        private void InitializePublishersTab(TabPage publishersTab)
        {
            publishersGridView = new DataGridView();
            publishersGridView.Dock = DockStyle.Fill;
            publishersTab.Controls.Add(publishersGridView);

            Button addButton = new Button { Text = "Добавить", Dock = DockStyle.Bottom };
            Button editButton = new Button { Text = "Изменить", Dock = DockStyle.Bottom };
            Button deleteButton = new Button { Text = "Удалить", Dock = DockStyle.Bottom };

            Panel buttonPanel = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            deleteButton.Location = new Point(250, 5);
            editButton.Location = new Point(150, 5);
            addButton.Location = new Point(50, 5);

            buttonPanel.Controls.Add(addButton);
            buttonPanel.Controls.Add(editButton);
            buttonPanel.Controls.Add(deleteButton);
            publishersTab.Controls.Add(buttonPanel);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
